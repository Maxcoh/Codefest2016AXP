Scripts in this folder are used with wamp server to pull csv data from MySql server.

Using MySequalRequest.php
The request to requires the tableName parameter which contains the name
of the database that the data is pulled from.

Format: [domain]/aquiphilly/MySequalRequest.php?tableName=[tablename]
Ex:	http://localhost/aquiphilly/MySequalRequest.php?tableName=table%2032
